#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 25 04:04:38 2023

@author: ethanfancher_snhu
"""

from pymongo import MongoClient
from bson.objectid import ObjectId

class CRUD(object):
    """ CRUD operations for MongoDB """

    def __init__(self, USER, PASS, HOST, PORT, DB, COL):
        # Initialize Connection
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        """
        Insert a document into the MongoDB database and collection.
        
        Args:
        - data (dict): A set of key/value pairs to insert.

        Returns:
        - bool: True if successful insert, else False.
        """
        try:
            if data:
                self.collection.insert_one(data)
                return True
            return False
        except Exception as e:
            print(f"Error: {e}")
            return False

    def read(self, lookup):
        """
        Query for documents from the MongoDB database and collection.
        
        Args:
        - lookup (dict): The key/value lookup pair.

        Returns:
        - list: List of results if the command is successful, else an empty list.
        """
        try:
            results = list(self.collection.find(lookup))
            return results
        except Exception as e:
            print(f"Error: {e}")
            return []
        
    def update(self, lookup, new_values):
        """
        Update documents in the MongoDB collection.
        
        Args:
        - lookup (dict): The key/value pair to find the documents that you want to update.
        - new_values (dict): The new key/value pairs that will be updated in the documents.
        
        Returns:
        - int: The number of documents updated.
        """
        try:
            # Using update_many to ensure all matching documents are updated.
            result = self.collection.update_many(lookup, {"$set": new_values})
            return result.modified_count
        except Exception as e:
            print(f"Error: {e}")
            return 0

    def delete(self, lookup):
        """
        Delete documents from the MongoDB collection.
        
        Args:
        - lookup (dict): The key/value pair to find the documents that you want to delete.
        
        Returns:
        - int: The number of documents deleted.
        """
        try:
            # Using delete_many to ensure all matching documents are deleted.
            result = self.collection.delete_many(lookup)
            return result.deleted_count
        except Exception as e:
            print(f"Error: {e}")
            return 0